package cs520.hw3.part2;

import java.io.File;
import java.util.Scanner;

public class TeamTest {
	private static String number;
	private static String name;
	private static String position;
	private static String year;

	public static double createPlayer(String number, String name, String position, String year) {
		int num = Integer.parseInt(number);

		Player player = new Player(name);
		player.setNumber(num);
		player.setName(name);
		player.setPosition(position);
		player.setYear(year);		
		return Player.computeScoringAverage();

	}

	public static void main(String[] args) {
//		double totalScoringAverage = 0;

		try {
			File file = new File("\\team.txt");
			Scanner scanner = new Scanner(file);

			while (scanner.hasNextLine()) {
				System.out.println(scanner.nextLine());
//				createPlayer(number, name, position, year);
//				totalScoringAverage += createPlayer(number, name, position, year);
//				System.out.print(totalScoringAverage / 10);

			}	      

		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
